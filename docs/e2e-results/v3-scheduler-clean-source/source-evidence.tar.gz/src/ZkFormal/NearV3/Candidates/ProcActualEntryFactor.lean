import ZkFormal.NearV3.Candidates.ProcActualRunFactor
import ZkFormal.NearV3.Candidates.ProcActualReplayEntry
namespace ZkFormal.NearV3.Candidates.ProcActualEntryFactor
open NearSpec NearSpecV3.Scheduler ZkFormal.NearV3.Sched ZkFormal.NearV3.Sched.Gen
def runRestEntries (I : Input) (tau : Nat) (conv : Array CReq) (stF : PState)
    (mrounds : List Round) : Except String Run := do
  let n := I.ids.length
  let p := I.p
  let N := n*n
  let lp := linkPass n p I.allowed (ProcActualInput.allowances I.ids I.prev)
  let al (l : Nat) : Bool := I.allowed[l]!
  let R := conv.size
  let key := NearSpecV3.leWords I.seed
  -- replay
  let mut sb := lp.sb
  let mut rb := lp.rb
  let mut aa := lp.a2
  let mut gg := lp.g2
  let mut opsL : Array (Array Gen.MOp) := Array.replicate N #[]
  let mut opsS : Array (Array Gen.MOp) := Array.replicate n #[]
  let mut opsR : Array (Array Gen.MOp) := Array.replicate n #[]
  for c in conv do
    let v := aa[c.link]!
    let w := gg[c.link]!
    opsL := opsL.modify c.link (·.push ⟨c.cid + 1, OP_READ, v, v, w, w, 0, false, false, false⟩)
  let tsOf (t : Nat) : Nat := if t < R then t else T0 + (t - R)
  let mut pushes : Array (Nat × Nat × Nat × Nat) :=
    conv.map fun c => (c.cid, c.key, if c.key = 0 then 1 else 0, c.cid * 64)
  let mut bucketsAll : Array (Nat × Nat × Nat × Nat) := #[]
  let mut T := T0
  let mut kpos := 0
  let mut Kq := Proc.KSENT
  let mut zq := 0
  let mut used : Array (Array Bool) := conv.map fun c => Array.replicate c.incs.length false
  let mut rounds : Array Gen.RoundD := #[]
  let mut gidx := 0
  for rd in mrounds do
    let L := rd.bucket.length
    check (L ≥ 1 && L < 16384) "bucket size"
    let vals := rd.bucket.map (·.v)
    let (sh, kend) ← replayShuffle key kpos vals
    check (sh == rd.shuffled) "shuffle replay differs"
    check (rd.steps.length == L) "steps ≠ bucket"
    for b in rd.bucket do
      check (b.key == rd.key && b.z == rd.z) "bucket push key/z"
      bucketsAll := bucketsAll.push (tsOf b.ts, b.key, b.z, b.v)
    let mut ents : Array Entry := #[]
    let (sbNext,rbNext,aaNext,ggNext,opsLNext,opsSNext,opsRNext,pushesNext,usedNext,gidxNext,entsNext) ← forIn (List.range L) (sb,rb,aa,gg,opsL,opsS,opsR,pushes,used,gidx,ents) (ProcActualReplayEntry.step I conv rd sh T)
    sb := sbNext
    rb := rbNext
    aa := aaNext
    gg := ggNext
    opsL := opsLNext
    opsS := opsSNext
    opsR := opsRNext
    pushes := pushesNext
    used := usedNext
    gidx := gidxNext
    ents := entsNext
    rounds := rounds.push ⟨rd.key, rd.z, T, L, kpos, kend, Kq, zq, ents.toList⟩
    T := T + L
    kpos := kend
    Kq := rd.key
    zq := rd.z
  -- every push is popped exactly once
  check (sortPush pushes.toList == sortPush bucketsAll.toList) "push log ≠ buckets"
  -- final state
  check (sb == stF.sb && rb == stF.rb && aa == stF.al && gg == stF.g) "final state differs"
  check (kpos == rngPos stF.rng) "final RNG position differs"
  -- memory segments
  let mut segs : Array Gen.Seg := #[]
  for l in List.range N do
    let b := al l
    segs := segs.push ⟨addrOf tau 0 l, true, b, b2n b, lp.a2[l]!, lp.g2[l]!, opsL[l]!.toList⟩
  for s in List.range n do
    segs := segs.push ⟨addrOf tau 1 s, false, false, 0, lp.sb[s]!, 0, opsS[s]!.toList⟩
  for r in List.range n do
    segs := segs.push ⟨addrOf tau 2 r, false, false, 0, lp.rb[r]!, 0, opsR[r]!.toList⟩
  -- comparator messages
  let cmpOf (x y : Nat) : Nat × Nat × Nat := (x, y, if y ≤ x then 1 else 0)
  let mut cmps : Array (Nat × Nat × Nat) := #[]
  for g in segs do
    let mut tp := 0
    for o in g.ops do
      check (tp < o.t) "memory times not increasing"
      cmps := cmps.push (cmpOf o.t (tp + 1))
      if o.op == OP_GRANT then cmps := cmps.push (cmpOf o.vin o.inc)
      tp := o.t
  for rd in rounds do
    if rd.K != 0 then
      check (rd.K < rd.Kq) "round keys not decreasing"
      cmps := cmps.push (cmpOf rd.Kq (rd.K + 1))
    let es := rd.entries.toArray
    for i in List.range es.size do
      let e := es[i]!
      let cx := if i + 1 = es.size then rd.T else es[i + 1]!.ts
      check (e.ts < cx) "bucket ts order"
      cmps := cmps.push (cmpOf cx (e.ts + 1))
  check (cmps.all fun (x, y, _) => x < 2 ^ 29 && y < 2 ^ 29) "comparison operand ≥ 2^29"
  let D := p.maxSingleGrant - p.base
  check (p.base < 2 ^ 24 && D < 2 ^ 24) "params ≥ 2^24"
  return { tau, n, base := p.base, D, seed := I.seed, key, a2 := lp.a2, conv := conv.toList,
           used, rounds := rounds.toList, segs := segs.toList, cmps := cmps.toList,
           kfin := kpos, fin := stF }

theorem rest_eq (I : Input) (tau : Nat) (conv : Array CReq) (st : PState) (rs : List Round) :
    ProcActualRunFactor.runRest I tau conv st rs=runRestEntries I tau conv st rs := rfl
end ZkFormal.NearV3.Candidates.ProcActualEntryFactor
